<?php
// Connect to database
         //   $servername = "localhost";
         $servername="192.168.1.134";
            $username = "david";
        //    $password = "aXVAcaMv5k08lLX6";
        $password="MBcaYoZElG[cRok6";

        
            $dbname = "alumnospdo";
          
            ?>
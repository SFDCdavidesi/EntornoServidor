<div style='display:block;float:left;width:100%;background-color:green;'>
        <div style='display:block;float:left;width:100%;background-color:blue;'>
            <div style='display:inline;float:left;width:80%;background-color:yellow;'>
                <a href='https://banknotescollection.com/viewBanknote/spain-1000-pesetas-23101979--P158-P158-769'>&nbsp;&nbsp;&nbsp;&nbsp;<b></b>9836051<b></b> - (SC-)   "" || billetesantiguos</a>
            </div>
            <div style='display:inline;float:right;width:15%;background-color:red;' class='colorPrice' >
                15€
            </div>
        </div>
    </div>
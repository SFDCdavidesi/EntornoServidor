<?php
require 'plugins/PHPMailer/PHPMailer.php';
require 'plugins/PHPMailer/SMTP.php';
require 'plugins/PHPMailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

function enviar_correo($to,$subject,$body): string{
    // Crea una nueva instancia de PHPMailer
    $mail = new PHPMailer(true);

try {
    // Configuración del servidor SMTP
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'almacen.de.david@gmail.com'; // Tu dirección de correo electrónico de Gmail
    $mail->isHTML(true);
    $mail->CharSet = 'UTF-8';
    $mail->Password='ialg kmpj beaq zyyo';
    
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587; // Puerto SMTP de Gmail

    // Configuración del correo
    $mail->setFrom('almacen.de.david@gmail.com', 'Club de Navegación');
    $mail->addAddress($to); // Dirección de correo electrónico del destinatario
    $mail->Subject = $subject;
    $mail->Body = $body;

    // Enviar el correo
    $mail->send();
    return 'El mensaje ha sido enviado correctamente.';
} catch (Exception $e) {
    return "Error al enviar el mensaje: {$mail->ErrorInfo}";
}
}
?>
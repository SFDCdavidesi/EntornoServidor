<?php include(__DIR__ . '../../View/header.php') ?>
<div class="muestra-error"><?=$error?></div>
<?php include(__DIR__ . '../../View/footer.php') ?>
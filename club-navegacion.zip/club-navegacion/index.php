<?php
// Redirige a la carpeta Controller
header("Location: controller/");
exit(); // Asegura que el script se detenga después de la redirección
?>
